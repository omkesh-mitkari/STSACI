
package urlhanding;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import ConvertActionForm;
public class formHelper
{
Object handleActionForm(String className,HttpServletRequest req) throws InstantiationException, IllegalAccessException, ClassNotFoundException{

	Object fc = Class.forName(className).newInstance();
	ConvertActionForm aform = new ConvertActionForm();
	aform.putFormClassName(fc);
	fc = aform.formBean(req);
	return fc;
}
}
