package urlhanding;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.*;
import java.util.*;

public class CreateController
{
	public static Hashtable<String,String> h = new Hashtable<String,String>();
	public static Hashtable<String,String> h1 = new Hashtable<String,String>();
	public static Hashtable<String,String> h2 = new Hashtable<String,String>();
	
	public static void addheader(FileWriter fstream1,BufferedWriter out1,String resultantName) throws IOException {
 
		File fin = new File("headerfiles.txt");
		FileInputStream fis = new FileInputStream(fin);
		BufferedReader in = new BufferedReader(new InputStreamReader(fis));
		String aLine = null;
		while ((aLine = in.readLine()) != null) {
			aLine = aLine.replaceAll("ProjectController",resultantName);
			out1.write(aLine);
			out1.newLine();
		}
		out1.close();
		in.close();
	}
	
	public static String searchInTable(Hashtable<String,String> h1,String searchKey)
	{
		Set<String> keys = h1.keySet();
        Iterator<String> iterator = keys.iterator();
        while(iterator.hasNext())
        {
        	String key= iterator.next();
        	if(key.equals(searchKey))
        		return h1.get(key);
        }
        return "NULL";
	}
	
	
	public static String processMethodName(String input)
	{
		/*int j=0;
		Stack<Character> stack = new Stack<Character>();
		Stack<Character> stack1 = new Stack<Character>();
		for(int i=0;i < oldString1.length();i++)
		{
			stack.push(oldString1.charAt(i));
		}
		while(stack.peek()!='/')
		{
			stack1.push(stack.pop());
		}

		int length = stack1.size();
		char[] processed = new char[length];
		while(!stack1.isEmpty())
		{
			processed[j]=stack1.pop();
			j++;
		}
		String result = String.valueOf(processed);
		return result;*/
		
		int j=0,flag=0;
		Stack<Character> stack = new Stack<Character>();
		Stack<Character> stack1 = new Stack<Character>();
		for(int i=0;i < input.length();i++)
		{
			
			stack.push(input.charAt(i));
		}
		while(!stack.isEmpty())
		{
			if(stack.peek()=='/'&& flag==0)
			{
				flag=1;
				stack1.push('_');
				stack.pop();
			}
			else if(stack.peek()=='/'&& flag==1)
			{
				stack1.push('_');
				stack.pop();
			}
			else if(stack.peek()=='-')
			{
				stack1.push('_');
				stack.pop();
			}
			else
				stack1.push(stack.pop());
		}

		int length = stack1.size();
		char[] processed = new char[length];
		while(!stack1.isEmpty())
		{
			processed[j]=stack1.pop();
			j++;
		}
		String result = String.valueOf(processed);
		return result;
		
		
	}
	
	public static void addControllerMethod(FileWriter fstream1,BufferedWriter out1,String oldString, String newString,String oldString1, String newString1,Hashtable<String,String> h1,Hashtable<String,String> h2) throws IOException {
		 
		File fin1 = new File("controllerMethodTemplate.txt");
		FileInputStream fis1 = new FileInputStream(fin1);
		BufferedReader in1 = new BufferedReader(new InputStreamReader(fis1));
		
		String formName;
		String className;
		String processedMethodName;
		formName = searchInTable(h2,newString1);
		className =searchInTable(h1,formName);
		System.out.println(className+"  "+formName);
		String aLine = null;
		processedMethodName=processMethodName(newString1);
		while ((aLine = in1.readLine()) != null) {
			aLine = aLine.replaceAll("methodName",processedMethodName);
			aLine = aLine.replaceAll(oldString, newString);
			aLine = aLine.replaceAll(oldString1, newString1);
			aLine = aLine.replaceAll("classNameString",className);
			out1.write(aLine);
			out1.newLine();
		}
		in1.close();
	}
	public static void addDispatcherServelet(FileWriter fstream1,BufferedWriter out1) throws IOException {
		 
		File fin = new File("dispatcherTemplate.txt");
		FileInputStream fis = new FileInputStream(fin);
		BufferedReader in = new BufferedReader(new InputStreamReader(fis));
		String aLine = null;
		while ((aLine = in.readLine()) != null) {
			out1.write(aLine);
			out1.newLine();
		}
		in.close();
	}	
	
	
	public static String getPrefix(String input)
	{
		int j=0;
		Stack<Character> stack = new Stack<Character>();
		Stack<Character> stack1 = new Stack<Character>();
		for(int i=0;i < input.length();i++)
		{
			stack.push(input.charAt(i));
		}
		while(stack.peek()!='.')
		{
			stack.pop();
		}
		stack.pop();
		while(!stack.isEmpty())
		{
			stack1.push(stack.pop());
		}
		int length = stack1.size();
		char[] processed = new char[length];
		while(!stack1.isEmpty())
		{
			processed[j]=stack1.pop();
			j++;
		}
		String result = String.valueOf(processed);
		return result;
	}
	public static String getControllerName(String input)
	{
		int j=0,flag=0;
		Stack<Character> stack = new Stack<Character>();
		Stack<Character> stack1 = new Stack<Character>();
		for(int i=0;i < input.length();i++)
		{
			stack.push(input.charAt(i));
		}
		while(stack.peek()!='.')
		{
			stack.pop();
		}
		stack.pop();
		while(!stack.isEmpty())
		{
			if(stack.peek()=='.' && flag==0)
			{
				stack1.push('_');
				stack.pop();
				flag=1;
			}
			if(stack.peek()=='.' && flag==1)
			{
				stack1.push('_');
				stack.pop();
				flag=2;
			}
			else if(stack.peek()=='.' && flag==2)
			{
				break;
			}
			else
			{
			stack1.push(stack.pop());
			}
		}
		int length = stack1.size();
		char[] processed = new char[length];
		while(!stack1.isEmpty())
		{
			processed[j]=stack1.pop();
			j++;
		}
		String result = String.valueOf(processed);
		return result;
	}
	
	public static String preprocessFileName(String input)
	{
		int j=0,flag=0;
		Stack<Character> stack = new Stack<Character>();
		Stack<Character> stack1 = new Stack<Character>();
		for(int i=0;i < input.length();i++)
		{
			
			stack.push(input.charAt(i));
		}
		while(!stack.isEmpty())
		{
			if(stack.peek()=='.'&& flag==0)
			{
				flag=1;
				stack1.push(stack.pop());
			}
			else if(stack.peek()=='.'&& flag==1)
			{
				stack1.push('/');
				stack.pop();
			}
			else
				stack1.push(stack.pop());
		}

		int length = stack1.size();
		char[] processed = new char[length];
		while(!stack1.isEmpty())
		{
			processed[j]=stack1.pop();
			j++;
		}
		String result = String.valueOf(processed);
		return result;
	}
	
	public static String getDirectory(String input)
	{
		int j=0;
		Stack<Character> stack = new Stack<Character>();
		Stack<Character> stack1 = new Stack<Character>();
		for(int i=0;i < input.length();i++)
		{
			stack.push(input.charAt(i));
		}
		while(stack.peek()!='/')
		{
			stack.pop();
		}
		stack.pop();
		while(!stack.isEmpty())
		{
			stack1.push(stack.pop());
		}
		int length = stack1.size();
		char[] processed = new char[length];
		while(!stack1.isEmpty())
		{
			processed[j]=stack1.pop();
			j++;
		}
		String result = String.valueOf(processed);
		return result;
	}
	
	public static String process_list(List<String> L1)
	{
		String Value="";
		for(int i=0;i<L1.size();i++)
		{
			Value=Value.concat(L1.get(i));
			Value+=",";
		}
		return Value;
	}
	
	public static void craete_property_file(Hashtable<String,List<String>> h1)
	{
		//Hashtable<String,String> h2 = new Hashtable<String,String>();
		String value;
		try {
			Properties properties = new Properties();
			Set<String> keys = h1.keySet();
	        for(String key: keys){
	        value = process_list(h1.get(key));
	        //h2.put(key, value);
	        properties.put(key, value);
	        }

			File file = new File("mappings.properties");
			FileOutputStream fileOut = new FileOutputStream(file);
			properties.store(fileOut, "JSP Mappings");
			fileOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	
	public static void Controller() throws IOException
	{
		FileWriter fstream1 = new FileWriter("C:\\Users\\mitkario\\Desktop\\test/controller.java", true);
		BufferedWriter out1 = new BufferedWriter(fstream1);
		//addheader(fstream1,out1);
		
		/* Hashtable to create the action class and url mappinfg*/
		h = xmlparser.getMappings();
		h2 = xmlparser.getFormHelpMappings();
		h1 = xmlparser.getFormMappings();
		
		Set<String> keys = h.keySet();
        Iterator<String> iterator = keys.iterator();
        
        Set<String> keys1 = h.keySet();
        Iterator<String> iterator1 = keys1.iterator();
        Set<String> hash_Set = new HashSet<String>();
        
        /*This module is used to get the unique controller names (Unique action class prefixes)*/ 
        while(iterator1.hasNext())
        {
        	String key= iterator1.next();
        	System.out.println(h.get(key));
        	String prefix;
        	prefix= getPrefix(h.get(key));
        	hash_Set.add(prefix); 
        }
        
        /*This module creates the separate controllers*/
        Iterator<String> it = hash_Set.iterator();
        while(it.hasNext())
        {
            String controllerName;
            //controllerName = getControllerName(it.next());
            File file = new File("C:\\Users\\mitkario\\Desktop\\test\\Controllers/"+it.next()+".java");
            file.createNewFile();
        }
        
        File folder = new File("C:\\Users\\mitkario\\Desktop\\test\\Controllers/");
        File[] listOfFiles = folder.listFiles();
        /*Add the header template to the file*/
        for (File file : listOfFiles) {
            if (file.isFile()) {
            	FileWriter fstream2 = new FileWriter(file.getAbsolutePath(), true);
        		BufferedWriter out2 = new BufferedWriter(fstream2);
        		String result = getControllerName(file.getName()); 
        		addheader(fstream2,out2,result);
            }
        }
        
        Set<String> keys3 = h.keySet();
        Iterator<String> iterator3 = keys3.iterator();
        Set<String> hash_Set1 = new HashSet<String>();
        
        while(iterator3.hasNext())
        {
        	String key= iterator3.next();
        	String result = getPrefix(h.get(key));
        	FileWriter fstream3 = new FileWriter("C:\\Users\\mitkario\\Desktop\\test\\Controllers/"+result+".java", true);
    		BufferedWriter out3 = new BufferedWriter(fstream3);
        	addControllerMethod(fstream3,out3,"ClassName",h.get(key),"/dummy",key,h1,h2);
        	out3.close();
        }
        
		out1.newLine();
		out1.write("}");
		out1.close();
		
		File folder1 = new File("C:\\Users\\mitkario\\Desktop\\test\\Controllers/");
        File[] listOfFiles1 = folder1.listFiles();
        /*Add the header template to the file*/
        for (File file : listOfFiles1) {
            if (file.isFile()) {
            	String finalName = getControllerName(file.getName()); 
            	File newName = new File("C:\\Users\\mitkario\\Desktop\\test\\Controllers/"+finalName+".java");
            	file.renameTo(newName);
            }
        }
		
        
        File folder2 = new File("C:\\Users\\mitkario\\Desktop\\test\\Controllers/");
        File[] listOfFiles2 = folder2.listFiles();
        for(File file : listOfFiles2)
        {
        	if(file.isFile())
        	{
        		FileWriter fstream2 = new FileWriter(file.getAbsolutePath(), true);
        		BufferedWriter out2 = new BufferedWriter(fstream2);
        		out2.newLine();
        		out2.write("}");
        		out2.close();
        	}
        }
        
	}
	public static void main(String args[]) throws Exception
	{
		ToolClass.SwitchCase(args[0]);
	}
}