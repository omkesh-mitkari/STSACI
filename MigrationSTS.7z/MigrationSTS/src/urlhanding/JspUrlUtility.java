package urlhanding;

public class JspUrlUtility {
public static String getPath(String input,String match)
{
	String[] parts = input.split(",");
	for(int i=0;i<parts.length;i++)
	{
		if(match.equals(parts[i]))
		{
			return parts[i+1];
		}
	}
	return "NULL";
}
}
