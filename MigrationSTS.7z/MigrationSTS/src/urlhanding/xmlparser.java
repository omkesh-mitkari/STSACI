package urlhanding;

import java.io.*;
import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class xmlparser {
		//String[] values = new String
		List<String> sentence =new  ArrayList<String>();
		
		public static Hashtable<String,String> h = new Hashtable<String,String>();
		public static Hashtable<String,String> h1 = new Hashtable<String,String>();
		public static Hashtable<String,String> h2 = new Hashtable<String,String>();
		public static Set<String> hash_Set = new HashSet<String>();
		public static Hashtable<String,List<String>> h3 = new Hashtable<String,List<String>>();
		public static Hashtable<String,String> getMappings() {
	      try {
	         
	    	 File inputFile = new File("C:\\Users\\mitkario\\Desktop\\CSR\\web\\WebContent/csr-struts-config.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         
	         Document doc = dBuilder.parse(inputFile);
	         
	         doc.getDocumentElement().normalize();
	         
	         System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
	         NodeList nList = doc.getElementsByTagName("action");
	         
	         System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               System.out.println(eElement.getAttribute("path"));
	               System.out.println(eElement.getAttribute("type"));
	               h.put(eElement.getAttribute("path"),eElement.getAttribute("type"));
	            }
	         }
	         
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
		  return h;
	   }
		
		public static Hashtable<String,List<String>> getForwardMappings()
		{
			//List<String> L= new ArrayList<String>();
			try
			 {
			 File inputFile = new File("C:\\Users\\mitkario\\Desktop\\CSR\\web\\WebContent/csr-struts-config.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         
	         Document doc = dBuilder.parse(inputFile);
	         
	         doc.getDocumentElement().normalize();
	         
	         //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
	         NodeList nList = doc.getElementsByTagName("action");
	         
	         System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            List<String> L= new ArrayList<String>();
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               //System.out.println(eElement.getAttribute("name"));
	               String type=eElement.getAttribute("path");
	               NodeList nList1 =eElement.getElementsByTagName("forward");
	               for(int temp1=0;temp1<nList1.getLength();temp1++)
	               {
	            	   Node nNode1 = nList1.item(temp1);
	            	   Element eElement1 =(Element) nNode1;
	            	   String name=eElement1.getAttribute("name");
	            	   String path = eElement1.getAttribute("path");
	            	   L.add(name);
	            	   L.add(path);
	            	   h3.put(type,L);
	            	   //System.out.println(eElement.getAttribute("path"));
	            }
	               
	         }
			 }
			 }
			 catch (Exception e) {
		         e.printStackTrace();
		      }
			Set s = h3.entrySet(); 
			  
	        // printing set entries 
	        System.out.println("set entries: " + s); 
			 return h3;
		}
		
		public static Hashtable<String,String> getFormMappings()
		{
			 try
			 {
			 File inputFile = new File("C:\\Users\\mitkario\\Desktop\\CSR\\web\\WebContent/csr-struts-config.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         
	         Document doc = dBuilder.parse(inputFile);
	         
	         doc.getDocumentElement().normalize();
	         
	         //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
	         NodeList nList = doc.getElementsByTagName("form-bean");
	         
	         System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               System.out.println(eElement.getAttribute("name"));
	               System.out.println(eElement.getAttribute("type"));
	               h1.put(eElement.getAttribute("name"),eElement.getAttribute("type"));
	            }
	         }
			 }
			 catch (Exception e) {
		         e.printStackTrace();
		      }
			 return h1;
		}
		public static Hashtable<String,String> getFormHelpMappings()
		{
			 try
			 {
			 File inputFile = new File("C:\\Users\\mitkario\\Desktop\\CSR\\web\\WebContent/csr-struts-config.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         
	         Document doc = dBuilder.parse(inputFile);
	         
	         doc.getDocumentElement().normalize();
	         
	         //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
	         NodeList nList = doc.getElementsByTagName("action");
	         
	         System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               System.out.println(eElement.getAttribute("name"));
	               System.out.println(eElement.getAttribute("path"));
	               h2.put(eElement.getAttribute("path"),eElement.getAttribute("name"));
	            }
	            
	         }
			 }
			 catch (Exception e) {
		         e.printStackTrace();
		      }
			 return h2;
		}
		
		public static Set<String> getUniqueClasses()
		{
			 try
			 {
			 File inputFile = new File("C:\\Users\\mitkario\\Desktop\\CSR\\web\\WebContent/csr-struts-config.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile);
	         
	         doc.getDocumentElement().normalize();
	         
	         //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
	         NodeList nList = doc.getElementsByTagName("action");
	         
	         //System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               //System.out.println(eElement.getAttribute("type"));
	               hash_Set.add(eElement.getAttribute("type"));
	            }
	            
	         }
			 }
			 catch (Exception e) {
		         e.printStackTrace();
		      }
			 
			 System.out.println(hash_Set);
			 
			 System.out.println(hash_Set.size());
			 
			 return hash_Set;
		}
}
